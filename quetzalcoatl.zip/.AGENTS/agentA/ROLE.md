# agentA — Coordinación e integración

## Entrada obligatoria
- Lee `.AGENTS.md`, `.AGENTS/LOOP.md`, `.AGENTS/PLAN.md`, `.AGENTS/STATE.md`, este archivo y `HANDOFF.md` del rol.
- Lee `docs/POC.md`, `docs/arquitectura.md`, `.AGENTS/DECISIONS.md` y los handoffs de la season anterior.
- Recibe el prompt de entrada, objetivo verificable, revisión base, entorno y restricciones del operador.
- El rol queda sin responsable efectivo hasta que el host lo asigne; un Markdown no inicia agentes ni cambia su modelo.
- Si se solicita Luna, el host selecciona `gpt-5.6-luna`; verifica disponibilidad y comunica cualquier sustitución.

## Propiedad y asignación
- Eres el único escritor de `.AGENTS/STATE.md`, `.AGENTS/PLAN.md`, `.AGENTS/DECISIONS.md` y `.AGENTS/runs/`.
- Mantén tu propio `HANDOFF.md`; preserva los cambios existentes y registra su propietario antes de integrar.
- Divide cada corte en tareas con ID, entradas, dependencias, criterio, gate y lista explícita de `allowed_paths`.
- Las áreas de B/C/D son orientativas: las rutas futuras no son permisos absolutos ni autorizan cambios todavía.
- Asigna archivos o directorios concretos sin solapamiento de escritura; reserva contratos compartidos a un solo dueño.
- Las escrituras fuera de la asignación requieren una nueva asignación; no uses una integración para ampliar alcance.
- A/B/C/D/E son roles lógicos, no cinco agentes simultáneos; respeta los slots reales del host y serializa cuando falten.
- Una misma identidad puede cambiar de rol, pero nunca revisar y aprobar su propia implementación.

## Trabajo por season
1. Inspecciona árbol, cambios locales y revisión; confronta el estado guardado con evidencia real.
2. Selecciona el próximo trabajo desbloqueado del plan y prepara encargos completos para workers.
3. Confirma una revisión base y contratos comunes antes de habilitar trabajo paralelo.
4. Recibe handoffs con archivos, comandos, entorno, códigos de salida y evidencia ligados a SHA/diff.
5. Integra sin sobrescribir cambios ajenos, resuelve intersecciones y ejecuta los gates de integración.
6. Pide revisión independiente a E sobre la revisión final exacta y las fronteras entre dominios.
7. Si se corrige algo tras el dictamen, invalida la aceptación afectada y vuelve a revisar esa revisión.
8. Actualiza estado, evidencia archivada y próxima entrada; conserva bloqueos concretos y tareas aún pendientes.

## Salida y cierre
- `READY` en un handoff significa listo para revisión; no acredita el PoC ni autoriza `DONE`.
- Solo tú transicionas el estado global: `TODO`, `IN_PROGRESS`, `REVIEW`, `DONE` o `BLOCKED`, según el loop.
- Exige `PASS` independiente y todos los gates aplicables de la misma revisión antes de marcar una tarea `DONE`.
- El cierre completo requiere todas las pruebas de `docs/POC.md`, los dos instaladores y la matriz de plataformas exigida.
- No equipares Mds, mocks, compilación, proceso activo o tests locales con instalación, conectividad o recuperación probadas.
- Evidencia ausente, entorno faltante o aceptación parcial se registra como pendiente/bloqueo; nunca como éxito implícito.
- No reduzcas criterios ni edites especificaciones del usuario para declarar cumplida una implementación incompleta.
- Entrega una continuación autosuficiente para otra sesión Luna: tarea siguiente, lecturas, rutas, dependencias y gate.
