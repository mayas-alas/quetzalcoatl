# Paquete de tarea (plantilla; completar antes de delegar)

- Season / tarea / rol / modelo solicitado y efectivo:
- Objetivo observable:
- Requisitos de PLAN y secciones de docs:
- Dependencias DONE y sus evidencias:
- Base de trabajo: rama, HEAD y cambios existentes que preservar:
- Rutas exclusivas que puede editar (incluido su HANDOFF):
- Archivos compartidos o prohibidos para esta asignación:
- Lecturas: contrato raíz, LOOP, PLAN, STATE, DECISIONS, ROLE, HANDOFF y fuentes:
- Criterios de aceptación, incluyendo casos negativos:
- Entornos y comandos de prueba; evidencia esperada por criterio:
- Integración con otras tareas y contrato que debe respetar:
- Reviewer independiente asignado:
- Resultado: READY / FAILED / ACTION_REQUIRED, con archivos, revisión y pruebas:
- Bloqueo externo, intentos y acción mínima para desbloquear, si aplica:
- Siguiente acción exacta:

No rellenes campos con éxito supuesto. Si falta una ruta, un requisito o un entorno
necesario, resuélvelo con agentA antes de tocar archivos fuera de la asignación.
