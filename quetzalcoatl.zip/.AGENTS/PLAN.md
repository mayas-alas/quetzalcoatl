# Backlog estable del PoC GNX

Fuente de alcance: [POC.md](../docs/POC.md) y [arquitectura.md](../docs/arquitectura.md), leídos completos. Este archivo organiza **trabajo futuro**; no demuestra que GNX exista ni que sus pruebas hayan pasado. Todos los ítems parten en `TODO`. El estado mutable, responsable activo, bloqueos y siguiente paso viven exclusivamente en [STATE.md](STATE.md); las pruebas y sus resultados se enlazan desde allí. Cambiar el estado de un ítem no exige modificar este plan.

Un ítem solo puede cerrarse cuando cumple **todos** sus criterios y agentE verifica evidencia de la revisión exacta. Un resultado simulado o una prueba local parcial se etiqueta como tal y no sustituye una prueba de plataforma o de cliente remoto. Si faltan VM, permisos, certificados, credenciales, clientes o infraestructura, se registra el bloqueo y se continúa con ítems independientes; nunca se inventa éxito.

Roles: **agentA** orquesta, integra y mantiene estado; **agentB** implementa core/runtime/DNS/ingress; **agentC** implementa host/broker/instaladores/tray; **agentD** implementa integraciones/apps/WatchTower/datos; **agentE** revisa contratos, seguridad, regresiones y evidencia. Toda implementación requiere revisión de agentE; agentA ratifica el cierre de las auditorías dirigidas por agentE. Ningún autor aprueba sus propios cambios de producto.

## Orden y dependencias

Las dependencias son requisitos de cierre. Se puede preparar trabajo independiente, pero no declarar un ítem cerrado ni publicar sus artefactos antes de aprobarlas. P03 es una puerta de viabilidad **previa al desarrollo del instalador Windows**; no basta con probar WSL bajo la cuenta interactiva del desarrollador.

| ID | Trabajo | Rol | Depende de |
|---|---|---|---|
| P00 | Alcance y decisiones de ejecución | agentA | - |
| P01 | Contratos tipados y configuración | agentB | P00 |
| P02 | Plan/aplicador y diagnóstico | agentB | P01 |
| P03 | Gate WSL bajo identidad de servicio | agentC | P00 |
| P04 | Runtime, identidades y fabric | agentB | P01, P02 |
| P05 | Autoridad CoreDNS y contrato de red | agentB | P04 |
| P06 | Caddy, portal y confianza TLS | agentB | P05 |
| P07 | Bundle NetBird independiente | agentD | P05, P06 |
| P08 | Bundle Tailscale independiente | agentD | P05, P06 |
| P09 | Aislamiento e independencia de integraciones | agentE | P07, P08 |
| P10 | Viabilidad y adaptación de WatchTower | agentD | P01, P04 |
| P11 | Build aislado y despliegue UI/CLI | agentD | P02, P06, P10 |
| P12 | PostgreSQL, recuperación y backups | agentD | P11 |
| P13 | Brokers, autorización y secretos | agentC | P01, P03, P04 |
| P14 | Payload compartido e instaladores | agentC | P03, P05, P06, P09, P10, P12, P13 |
| P15 | Tray, launcher y experiencia de acceso | agentC | P14 |
| P16 | Calificación de plataformas y fallos | agentE | P09, P11, P12, P13, P14, P15 |
| P17 | Empaquetado, firmas y publicación preparada | agentC | P16 |
| P18 | Auditoría y cierre integral del PoC | agentA | P17 |

P07 y P08 se prueban desde clientes separados o en ejecuciones separadas. La coexistencia de ambos clientes en un escritorio no forma parte de la aceptación. El mismo agente no desarrolla dos ítems simultáneamente: agentA asigna cada temporada según capacidad y dependencias.

## Criterios por ítem

### P00 — Alcance y decisiones de ejecución

- Aplicar este alcance al iniciar la implementación: un nodo x86-64, una organización, demo web, PostgreSQL, backup/restauración y despliegue; dos instaladores y un payload Linux interno común.
- Registrar decisiones faltantes: lenguaje/herramientas, schemas finales, versiones compatibles de CoreDNS/Caddy/Podman/systemd y Linux/WSL, política de publicación, hosts/clientes de prueba, almacenamiento externo y material de firma. Ejemplos de IP, repositorio y digest de los documentos no son valores de producción.
- Mantener fuera del cierre: HA, Kubernetes, scheduler distribuido, catálogo de bases múltiples, ejecución remota arbitraria, agente LLM dentro del producto, virtualización anidada/Proxmox, migradores legacy, webhooks y coexistencia de mallas en el mismo endpoint.
- Evidencia: decisiones fechadas, alcance de la temporada y matriz de entornos disponibles/faltantes. No importar código del PoC anterior por inercia.

### P01 — Contratos tipados y configuración

- Implementar schemas versionados para `gnx.toml`, `apps.d/*.toml`, contrato `network.toml`, solicitudes locales y resultados `READY`, `FAILED`, `ACTION_REQUIRED` con fase y código estable.
- Validar IDs, hostnames, puertos, referencias de credenciales, digests y estrategia de escritura/migración; zona configurable. Rechazar Quadlets libres, rutas del host, flags de Podman, shell/argv arbitrario y elevación de `workload` a `integration` desde un repositorio.
- `kind=integration` requiere bundle revisado, instalación administrativa y concesiones explícitas. El contrato de red contiene zona, nameservers, rutas `/32`, protocolos y nombre de salud; carece de tokens y modelos de fabricante.
- Evidencia: contratos documentados y pruebas positivas/negativas de validación; UI y CLI tienen una sola fuente de intención, con historial/sesiones del panel separado de la configuración efectiva.

### P02 — Plan/aplicador y diagnóstico

- Ofrecer `gnx plan`, `apply`, `status`, `doctor`, `apps deploy <id>` y `apps rollback <id>` mediante operaciones tipadas. Empezar con módulos y bibliotecas mantenidas; no crear framework de plugins, bus de eventos o supervisor propio.
- Aplicar con bloqueo por nodo, un escritor por recurso, plantillas deterministas, diferencias y publicación de una revisión coherente. Registrar intención/revisión efectiva/digest/commit sin secretos.
- Una segunda aplicación idéntica no reinicia servicios ni recrea volúmenes. Cambios de IP, digest o configuración actualizan referencias conjuntamente; cambiar solo la imagen no cambia DNS si el hostname sigue igual.
- Evidencia: planes y diferencias reproducibles, prueba concurrente del bloqueo, segunda aplicación sin cambios y pruebas de fallo que conservan la revisión anterior. `is-active` solo no autoriza `READY`.

### P03 — Gate WSL previo al instalador Windows

- Probar en Windows 11 x64 limpio y WSL2 soportado un broker SCM mínimo bajo **cuenta estándar dedicada**, con derecho de servicio y sin inicio interactivo/remoto. Cargar su perfil, importar la distro bajo esa identidad y comprobar su propiedad.
- Arrancar y ejecutar el runtime con systemd tras reboot **sin login humano** y recuperarlo tras `wsl --shutdown`. Deshabilitar automount e interop Windows en la distro.
- Verificar ACL de VHD/estado y acceso negativo del operador normal; la cuenta sensible nunca pertenece a Administrators. Administrators y SYSTEM quedan dentro de la frontera de confianza documentada.
- Evidencia: versión/VM identificada, identidad y grupos efectivos, configuración SCM/WSL, logs de arranque y recuperación, y pruebas negativas. Una sesión interactiva, WSL ya encendido o un broker administrador no aprueban la puerta.
- Si falla, registrar causa y decisión requerida. Se pueden avanzar cortes Linux independientes, pero **no construir el instalador Windows ni afirmar viabilidad Windows** hasta aprobar o recibir una revisión explícita del alcance.

### P04 — Runtime, identidades y fabric

- Infraestructura con systemd de sistema y Quadlets; workloads/DB rootless en usuario `gnx-apps` con linger, UID/subUID/subGID. Identidad separada de build. Directorios, sockets y secretos con permisos mínimos.
- Usar `.container`, `.network`, `.volume`, `.service`, `.timer`; ningún `.pod`, `.kube`, Compose, Podman Machine ni supervisor alternativo. Mantener los nombres y rutas previstos en arquitectura §§2/7.
- Elegir bridge/subred sin colisión con LAN/VPN/rutas. Workloads publican puertos altos solo accesibles por ingress; redes rootless por proyecto y DB sin exposición predeterminada. Integraciones en namespaces separados con TUN/capacidades acotadas, sin `Network=host`.
- Evidencia: unidades generadas y efectivas, identidades/permisos, topología real, Podman sin pods, pruebas de alcance y rechazo de colisiones. El core inicia sin bundles de malla.

### P05 — CoreDNS y contrato de red

- CoreDNS es autoridad única de `gnx`: zona ordenada, SOA incremental, TTL inicial 60, `mesh`, `apps`, `demo`, `ns` y wildcard configurable. Validar con la misma versión fijada antes de reemplazar atómicamente; `file` recarga la zona.
- Publicar contrato sin proveedor ni credenciales; split DNS recibe `gnx`, nunca `*.gnx`. Rechazar dominios externos sin reenviarlos; salud/readiness HTTP solo en loopback.
- Desde LAN probar SOA/A, wildcard activado y desactivado, NXDOMAIN/NODATA válidos y REFUSED fuera de zona, por UDP **y** TCP. Al probar NXDOMAIN considerar que el wildcard habilitado resuelve nombres que de otro modo serían inexistentes.
- Evidencia: consultas desde cliente LAN, captura/observación de ausencia de consultas privadas a upstream público, medición de propagación/TTL, reinicio CoreDNS y zona inválida. Un fallo conserva la revisión válida y evita `READY` hasta recuperar servicio útil.

### P06 — Ingress, portal y TLS

- Caddy con `tls internal`, CA persistente privada y renovación propia de Caddy; no implementar otra PKI. `mesh.gnx` ofrece estado/accesos/diagnóstico, `apps.gnx` autenticación y sesiones propias; hosts no declarados se rechazan incluso si DNS wildcard resuelve.
- Instalar la raíz **pública** mediante acción identificable y verificar su huella por canal autenticado en clientes remotos. La clave privada permanece en el runtime.
- Caddy elimina/sobrescribe cabeceras de identidad del cliente. Panel, API Caddy y socket Podman permanecen privados; DB no accesible desde las mallas.
- Evidencia: acceso LAN HTTPS con confianza válida, pruebas negativas de host/cabeceras/autenticación, inspección de exposición y persistencia TLS tras reinicio. Solo conectividad + DNS + TLS permite marcar un cliente listo.

### P07 — NetBird

- Bundle propio consume `network.toml`; publica solo DNS e ingress `/32`, configura Internal Nameserver para `gnx` y mantiene sus credenciales en su canal privado. Configuración manual del control plane es válida si queda reproducible y verificada.
- Router aislado con SNAT/masquerade y firewall TCP/UDP 53 + TCP 443; sin Custom Zones, DNS propietario en core ni anuncio del rango de otra malla. No instalar su control plane como requisito de GNX.
- Evidencia: desde cliente NetBird autorizado resolver el mismo A del contrato y abrir `mesh.gnx` con TLS confiable; cliente sin permisos rechazado. Resultado específico con rutas/DNS realmente aplicados, no solo respuesta de API.

### P08 — Tailscale

- Bundle independiente consume el mismo contrato; aprueba dos rutas `/32` y nameserver restringido a `gnx`, preservando MagicDNS y resolvers ajenos. Credenciales limitadas al bundle y control plane externo.
- Router aislado con SNAT/masquerade y firewall acotado. No depender de certificados `ts.net` para `.gnx` ni añadir un `MeshProvider`/`connect()` universal.
- Evidencia: desde cliente Tailscale autorizado resolver el mismo A de P07 y abrir `mesh.gnx` con TLS confiable; cliente sin permisos rechazado. Configuración manual documentada es aceptable; la respuesta de API sola no lo es.

### P09 — Independencia y aislamiento de mallas

- Verificar que no hay tránsito entre overlays, rutas cruzadas, acceso lateral a control ni colisiones aun con rangos `100.64.0.0/10` coincidentes en namespaces separados.
- Caer el control plane de cada integración por separado: CoreDNS, Caddy, LAN y la otra integración continúan. Registrar qué estado distribuido conserva cada app y qué operaciones remotas fallan; no inferir disponibilidad futura del fabricante.
- Iniciar y completar gates sin NetBird/Tailscale. Auditar que `core`, `dns`, `ingress` no importan SDK/modelos/API de proveedor. Desinstalar una integración elimina únicamente sus unidades, estado y credenciales.
- Evidencia: pruebas reales en ambos sentidos, caída/restitución controlada y análisis de dependencias; cliente Windows existente conserva configuración ajena a GNX. Ningún endpoint necesita ambas mallas para aprobar.

### P10 — Viabilidad WatchTower y frontera de ejecución

- Evaluar el upstream **sinhaankur/WatchTower** fijado en los documentos, no `containrrr/watchtower`. Auditar archivos/dependencias elegidos, excluir `pro/`, conservar Apache/avisos/atribuciones y resolver la discrepancia de términos antes de redistribuir material afectado.
- Demostrar primero un backend GNX Quadlet explícito: solicitudes app/revisión/digest hacia aplicador + systemd. Sustituir rutas de `local_runner.py`, `managed_db_runtime.py`, `podman_runtime.py`; sin shim llamado `podman`, pods, Machine, shell remota ni doble supervisor.
- Reutilizar solo interfaz/modelos compatibles, con nombre público GNX. Panel sin socket Podman de infraestructura, CA, credenciales de malla, root ni argv arbitrario. Deshabilitar endpoints antiguos en backend, no solo ocultarlos.
- Evidencia: despliegue mínimo trazado hasta systemd, prueba negativa directa de endpoints y auditoría de licencias por archivos. Si separar el backend falla, registrar fallback CLI/portal y **alcance WatchTower pendiente**; el fallback no aprueba P10 ni el PoC completo sin revisión explícita de alcance.

### P11 — Build y releases UI/CLI

- UI y CLI despliegan el mismo contrato/revisión; repositorio no confiable resuelto a commit fijo. Build limitado por CPU/memoria/tiempo, en identidad distinta, sin secretos/sockets de runtime; salida OCI por digest inmutable.
- Credenciales de Git/registro por archivo/socket protegido, nunca tokens en URL/argv. `gnx apps deploy demo` es el disparador inicial; timer opcional fija commit. No abrir exposición pública para webhooks.
- Iniciar candidato en puerto interno alterno, comprobar health, cambiar upstream Caddy y verificar; ante fallo conservar/restaurar upstream/release anterior. Datos separados de release; sin prometer cero downtime para escritura compartida.
- Evidencia: repo → commit → digest → revisión en UI/CLI → `https://demo.gnx`; prueba de aislamiento de build, release buena/mala y fallo posterior al cambio de upstream. Solo systemd supervisa; panel mantiene historial efectivo sin otra configuración de despliegue.

### P12 — PostgreSQL, recuperación y datos

- PostgreSQL en contenedor/red/volumen rootless por proyecto, con credencial propia. Migración aditiva explícita en demo; la reversión de imagen no pretende deshacer un schema incompatible.
- Backups con dump consistente, archivo cifrado, copia externa, timer y retención configurada; caché de build excluida. Restaurar en volumen separado y comprobar contenido, no solo existencia del archivo.
- Recuperación: `Restart=on-failure` con límites/frecuencia systemd, reintento acotado de descarga transitoria y rechazo de release no saludable. Conservar causa/fase/acción sin secretos; no modificar código, permisos, puertos, credenciales ni borrar datos para resolver fallos.
- Evidencia: reinicios limitados medidos, descarga recuperada, release previa usable, dump restaurado y comparación de datos tras migración aditiva. Registrar estrategia de schema compatible/restauración planificada para cambios incompatibles.

### P13 — Brokers, autorización y secretos

- Broker Windows SCM usa identidad y propiedad WSL aprobadas en P03; pipe versionado autoriza SIDs concretos, rechaza remotos y limita payload/operaciones. Ejecuta comando Linux fijo con entrada por stdin. Linux usa Unix socket con UID/grupo/permiso de operación equivalente.
- Operador accede solo a acciones autorizadas; no obtiene terminal bajo identidad sensible ni `wsl --exec` de GNX. Panel puede operar workloads autorizados; integración, políticas de red y confianza TLS requieren acción administrativa distinta.
- Guardar/transmitir secretos por canales privados con acceso mínimo; cada app recibe los suyos. Rotarlos sin crear por accidente una nueva identidad de nodo.
- Evidencia: intentos negativos VHD/pipe/socket, SID/UID no autorizados, cliente remoto, payload excesivo/inválido y shell/ruta/argv arbitrarios. Secretos canario detectables ausentes de Git, TOML, imágenes, URLs, argv, `inspect`, logs **y evidencia**; redacción de resultados antes de guardar.

### P14 — Payload y dos instaladores

- Construir payload Linux versionado/verificado compartido e interno: `GNX-Setup-x64.exe` y `gnx-linux-x86_64.run` son las dos descargas finales. No iniciar el instalador Windows antes de P03 ni empaquetar supuestos pendientes de P05–P10.
- Windows: verificar firma/payload/espacio/virtualización/WSL; elevación solo para instalar/habilitar, fase durable ante reinicio; Program Files público/ProgramData privado; crear cuenta estándar, broker/perfil/distro/systemd; CLI en PATH y prueba del portal desde Windows antes de mostrar éxito.
- Linux: Ubuntu 24.04 y Debian 13 x86-64; validar systemd/cgroup v2/Podman/Quadlet/TUN y payload antes de modificar. Ofrecer `--check`, interactivo y `--headless`; paquetes confiables, identidades/subUID/subGID, socket, unidades, linger y configuración administrada que el servicio web no pueda sobrescribir arbitrariamente.
- Instalar solo integraciones elegidas. Para acceso de escritorio por malla, reutilizar cliente existente o instalar el oficial verificado elegido; nunca exigir ambos. Completar acceso LAN sin malla. Headless entrega estado e instrucciones de acceso, sin UI.
- Update conserva revisión anterior y revierte tras health fallido. Uninstall separa binarios y datos, y exige decisión explícita antes de borrar volúmenes/credenciales/backups; no toca distros, contenedores ni mallas ajenas. Distros no calificadas reciben diagnóstico de compatibilidad.
- Evidencia: builds y pruebas de cada flujo en VM limpia; firmas/checksums verificados, interrupción/reanudación/reinicio, reejecución idempotente, actualización buena/mala y desinstalación con preservación de datos.

### P15 — Tray y acceso del operador

- Windows nativo: **clic derecho abre `https://mesh.gnx`; clic izquierdo abre menú Estado, Abrir GNX, Diagnóstico, Salir del tray**. Salir del tray deja servicios activos. Consulta contrato local, abre enlaces y no guarda claves ni ejecuta privilegios.
- Linux comprueba StatusNotifier/AppIndicator y comportamiento real del escritorio; si impone otro gesto, entregar launcher e informar limitación. Headless sin UI; no añadir Electron solo por el icono.
- Evidencia: capturas/registro de interacción en Windows y escritorios Linux calificados, portal confiable, diagnóstico visible y servicios activos tras salir; fallback probado donde el gesto exacto no sea compatible.

### P16 — Calificación integral y fallos

- Ejecutar los cinco cortes y siete casos críticos de POC §5 en Windows 11 x64 limpio, Ubuntu 24.04 y Debian 13 según corresponda. Registrar versiones exactas, capacidades, cliente, revisión/digests, pasos, esperado, resultado y artefactos de evidencia sin secretos.
- Comprobar reboot, arranque sin login humano, `wsl --shutdown` en Windows, reejecución sin cambios, instalación interrumpida, actualización/reversión, desinstalación y tray/launcher/headless. Validar endpoints útiles, nunca solo procesos activos.
- Repetir pruebas afectadas por defectos corregidos y verificar la revisión que irá a publicación. Todo fallo tiene estado/fase/código estable y acción; una plataforma sin pruebas no queda soportada por inferencia.
- Evidencia: matriz siguiente completa, resultados trazables y revisión independiente de agentE. Simulaciones, revisión de Markdown y Mermaid no prueban instalación, conectividad ni restauración.

### P17 — Entrega verificable

- Preparar exactamente los dos instaladores finales; payload común incorporado, versiones fijadas, checksum/firma, inventario de dependencias y avisos/licencias. El `.exe` final está firmado; material de firma faltante bloquea esta aceptación.
- Documentar instalación/actualización/desinstalación, matriz realmente calificada, acceso LAN/malla/TLS, diagnóstico, backup/restauración y limitaciones conocidas. No anunciar como final un instalador sin todos los cortes de su plataforma.
- Evidencia: verificación independiente de firmas/checksums, correspondencia binario ↔ revisión probada ↔ inventario/licencias y guía reproducible. Preparar publicación no autoriza por sí solo envío externo; actuar conforme a la autorización vigente de la sesión de implementación.

### P18 — Cierre completo, una vez verificable

- agentA concilia cada ID con STATE y sus pruebas; agentE confirma alcance y revisión final. No hay dependencia pendiente, fallo abierto que incumpla aceptación ni WatchTower reemplazado silenciosamente por fallback.
- Entregar dos instaladores verificables y resultados de todos los cortes/casos. Registrar fecha/revisión de cierre, artefactos, entornos y limitaciones aceptadas explícitamente; cerrar una sola vez esa revisión. Un cambio posterior abre trabajo afectado y requiere nueva evidencia.
- Si existe bloqueo externo, informar qué falta y qué sí está probado; no usar `PoC completo`, `READY` global ni final de plataforma como sinónimos de scaffolding, compilación o revisión documental.

## Matriz de trazabilidad obligatoria

| Fuente | Obligación de cierre | Ítems y evidencia principal |
|---|---|---|
| POC §5, corte 1 | DNS autoritativo LAN UDP/TCP, wildcard, negativos, rechazo externo | P05 → consultas/captura/TTL |
| POC §5, corte 2 | Dos integraciones por separado, mismo A, TLS, autorización y aislamiento | P06–P09 → clientes reales y pruebas negativas |
| POC §5, corte 3 | Windows limpio + dos Linux, reboot/sin login, idempotencia, interrupción, tray | P03, P13–P16 → matriz de VM y UX |
| POC §5, corte 4 | UI/CLI misma revisión, backend GNX, systemd único, sin pods/socket privilegiado | P10, P11 → trazas y rechazos backend |
| POC §5, corte 5 | Release mala, reinicio limitado y restauración con datos verificados | P11, P12 → fallos inyectados y comparación de datos |
| POC §5, crítico 1 | Reinicio/zona inválida, revisión previa, sin fugas, readiness y TTL | P05 → falla/recuperación y mediciones |
| POC §5, crítico 2 | Caída control de una malla preserva LAN y otra integración | P09 → pruebas de caída por bundle |
| POC §5, crítico 3 | Core sin mallas ni dependencias de proveedor; uninstall limitado | P04, P09, P14 → arranque, imports y diferencia de recursos |
| POC §5, crítico 4 | Cambio IP/digest/config coherente; segunda aplicación sin reinicio global | P02, P11 → plan/revisión y comportamiento efectivo |
| POC §5, crítico 5 | Cliente Windows preexistente intacto; negativos VHD/pipe | P03, P09, P13, P14 → antes/después y acceso denegado |
| POC §5, crítico 6 | Secretos canario ausentes; rotación sin nueva identidad | P13 → escaneo redactado y node ID estable |
| POC §5, crítico 7 | WatchTower sin pods/Machine/shell; rechazo real de endpoints retirados | P10, P11 → prueba directa del backend |
| Arquitectura §§3–8 | Fabric, TLS, contrato externo, fuente única, runtime y frontera de confianza | P01–P09, P13 → contratos, permisos y pruebas de red |
| POC §§2–4/6 | Dos artefactos, licencias, UI/CLI/build, datos, mantenimiento y límites | P00, P10–P18 → auditoría y entrega reproducible |

## Ambigüedades que requieren decisión, no suposiciones de éxito

- Los documentos son propuestas: schemas, versiones finales y herramientas de build se fijan en P00/P01 con evidencia de compatibilidad. Los valores de ejemplo nunca satisfacen pruebas reales.
- La viabilidad de WSL como servicio bajo cuenta estándar está pendiente de P03; ningún instalador ni workaround con administrador puede sustituirla.
- La reutilización WatchTower y el alcance de sus licencias requieren P10. La contingencia CLI/portal permite progreso, pero deja integración pendiente salvo modificación explícita del alcance.
- Se necesita acceso real a plataformas, clientes/control planes, almacenamiento externo y firma. Los faltantes se registran en STATE; configuración manual de control plane está permitida, evidencia inventada no.
- Linux puede carecer del gesto exacto del tray: el fallback declarado y probado satisface únicamente la condición prevista en POC §2; no permite afirmar compatibilidad con todos los escritorios.
