# Gauntlet loop

## Entrada y estado

Una campaña atraviesa tantas seasons como necesite. La entrada se reinyecta desde
[START](START.md), siempre leyendo archivos actuales. STATE contiene una sola fila
por tarea de PLAN, y cada reporte de season conserva sus resultados históricos.

Estados de tarea:

```text
TODO -> IN_PROGRESS -> REVIEW -> DONE
              ^          |
              +-- fallo -+
TODO / IN_PROGRESS / REVIEW -> BLOCKED -> TODO (al resolver causa)
DONE -> TODO (si un cambio invalida su evidencia; reabrir dependientes afectados)
```

`READY`, `FAILED`, `ACTION_REQUIRED` describen resultados GNX o entregas de workers;
no sustituyen estados de tarea. READY de un worker solo solicita revisión.
Una tarea DONE sigue requiriendo que todos sus prerrequisitos estén DONE.

## Ciclo obligatorio

1. **Recuperar.** Lee los archivos comunes y el último reporte. Inspecciona rama,
   diff y procesos/trabajos activos. Confirma si un IN_PROGRESS sigue vivo; si su
   dueño terminó, conserva el diff, registra recuperación y reasigna lo pendiente.
   No vuelvas a implementar una entrega existente sin inspeccionarla.
2. **Elegir.** agentA toma el primer TODO con dependencias DONE, o una corrección
   pendiente. Define criterios antes del código. En P00 fija comandos/versiones
   y decisiones aún abiertas sin convertir preguntas rutinarias en bloqueos.
   Usa trabajo independiente en paralelo solo si tiene rutas exclusivas.
3. **Asignar.** Genera un [paquete](templates/TASK.md) por tarea en
   `.AGENTS/runs/Sxxx-Pxx-agentX.md`, escribe responsable e IN_PROGRESS en STATE
   y actualiza su HANDOFF. Entrega a cada worker el paquete y rutas de lectura;
   explicita modelo, límites, dependencias y resultados esperados. Cada instancia
   de un rol atiende una tarea a la vez.
4. **Implementar.** El worker realiza el cambio mínimo completo y pruebas adecuadas
   a la aceptación. Investiga errores usando causas concretas. Captura comandos,
   exit codes, entorno, archivos y revisión. Un entorno que falta produce
   ACTION_REQUIRED, no un PASS sintético.
5. **Integrar y verificar.** agentA inspecciona la entrega y el diff, integra sin
   pisar trabajo ajeno y verifica las fronteras tocadas. Pasa a REVIEW solo si
   cumple sus pruebas. Registra una revisión de Git; con cambios sin commit usa
   HEAD más hash de los archivos relevantes, incluidos archivos nuevos.
6. **Revisión independiente.** agentE (o una sesión separada de revisor) lee el
   requisito original, reproduce pruebas necesarias y busca regresiones. Revisa
   también permisos y caminos negativos relevantes. Devuelve PASS/FAIL/BLOCKED,
   hallazgos con archivos y evidencia ligada a esa revisión. No acepta por el
   resumen del implementador. Si agentE implementó una corrección, otro revisor
   debe aprobarla. Serializar roles en una sola sesión no cuenta como independencia.
7. **Corregir.** FAIL vuelve a IN_PROGRESS con hallazgos concretos. Repite el ciclo
   de pruebas/revisión sobre la revisión nueva. Tras tres intentos sin avance sobre
   la misma causa, cambia de hipótesis o divide la tarea; si requiere intervención
   externa documenta BLOCKED. No hagas un bucle infinito ni apruebes por agotamiento.
8. **Persistir y continuar.** Solo agentA pone DONE después de PASS y guarda enlaces
   de evidencia/revisión en STATE, HANDOFF y reporte. Ejecuta el validador documental
   y elige la siguiente tarea disponible. Mantén la campaña ACTIVE mientras haya
   trabajo ejecutable; al final aplica las reglas de salida.

## Checkpoint y recuperación

Antes de una interrupción conocida o de devolver el control:

- Guarda por separado tarea, fase, cambios, pruebas ejecutadas y pruebas pendientes.
- En el reporte [de season](templates/SEASON.md), anota HEAD + hashes del estado
  revisado, modelo efectivo, asignaciones activas y cada dictamen independiente.
- Actualiza STATE con season, último reporte y siguiente acción/comando concreto.
- Conserva el historial en `runs/` antes de reemplazar un HANDOFF. No guardes secretos
  ni salidas crudas sensibles; la evidencia se redacta sin invalidar el resultado.

Si el contexto termina, el checkpoint puede estar parcial: la siguiente sesión
reconcilia archivos y procesos antes de confiar en él. Un límite de sesión deja
PoC ACTIVE y una acción de reanudación; no significa COMPLETE ni bloqueo externo.

## Gates y salida

PLAN traduce todos los cortes y casos críticos de las especificaciones. Cada tarea
debe enlazar una prueba que observe su comportamiento; simulación y pruebas unitarias
se identifican como tales. Pruebas en host real, malla real, VMs limpias y reinicio
permanecen pendientes hasta ejecutarse en esos entornos.

PoC admite NOT_STARTED, ACTIVE, BLOCKED y COMPLETE. BLOCKED global se usa cuando
no queda trabajo ejecutable y hay una dependencia externa documentada; no marca
como fallidas las tareas ya aceptadas. COMPLETE exige todas las tareas DONE, cierre
de todos los gates reales, revisión final independiente y ambos artefactos finales
con evidencias verificables. Ningún fallback de WatchTower o build sin firma se
presenta como cumplimiento total de la especificación.

La respuesta final de cada season indica avance aceptado, pruebas y siguiente
acción o bloqueo. Usa «PoC completo» solo con COMPLETE. El validador `check` verifica
estructura y dependencias; no certifica que GNX funcione ni que una evidencia sea cierta.
