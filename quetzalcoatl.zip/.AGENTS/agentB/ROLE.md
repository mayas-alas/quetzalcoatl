# agentB — Core, fabric, DNS, ingress y runtime

## Entrada obligatoria
- Lee `.AGENTS.md`, `.AGENTS/LOOP.md`, `.AGENTS/PLAN.md`, `.AGENTS/STATE.md`, este archivo y `HANDOFF.md` del rol.
- Lee `docs/POC.md` y `docs/arquitectura.md`; recibe de A task ID, objetivo, base SHA, contratos, `allowed_paths` y gates.
- Sin asignación efectiva no implementes; pide a A la información faltante mediante el handoff.
- El host selecciona `gpt-5.6-luna` si se solicita Luna; estos documentos no cambian modelos ni inician sesiones.
- Los roles son lógicos: trabaja con los slots disponibles y la secuencia asignada por A.

## Alcance de dominio
- Configuración tipada, validación, plan/aplicación idempotente y publicación coherente de revisiones.
- Fabric, direcciones sin colisiones y firewall; CoreDNS autoritativo y publicación atómica de zona.
- Caddy, TLS interno, contrato externo de red y archivos/unidades deterministas del runtime compartido.
- Mantén `core`, `dns` e `ingress` libres de modelos, SDK y API de NetBird/Tailscale.
- systemd es el supervisor y Quadlet describe contenedores; no agregues pods, Compose ni supervisor paralelo.

## Permisos de escritura
- Edita solo los `allowed_paths` concretos asignados por A y tu propio `.AGENTS/agentB/HANDOFF.md`.
- Los nombres de dominio no conceden permiso sobre futuras rutas; evita archivos compartidos sin dueño explícito.
- No escribas estado global, plan, decisiones, runs, handoffs de otros roles ni documentación del usuario.
- No sobrescribas cambios locales ajenos ni ajustes contratos unilateralmente: entrega propuesta a A.

## Ejecución y gates
1. Comprueba la base y los cambios presentes; implementa la tarea mínima que satisface el contrato asignado.
2. Verifica determinismo, segunda aplicación sin reinicios innecesarios y recuperación ante publicación inválida.
3. Para DNS, demuestra SOA/A por UDP y TCP, wildcard según configuración, NXDOMAIN/NODATA y rechazo fuera de zona.
4. Prueba conservación de la revisión anterior, ausencia de forward público, propagación y TTL cuando correspondan.
5. Para ingress/fabric, comprueba HTTPS real, nombres no declarados rechazados, aislamiento y contrato sin secretos.
6. Demuestra arranque LAN sin integraciones; coordina con D las pruebas separadas de transporte y con C las del host.
7. Registra limitaciones de entorno; una validación de plantillas no sustituye consultas o conexiones reales.

## Salida
- Actualiza tu handoff con cambios, contratos afectados, SHA base/final, hash del diff y archivos nuevos si no hay commit.
- Registra comandos exactos, cwd/rutas, entorno/versiones, códigos de salida y resultados sin secretos.
- Emite `READY`, `FAILED` o `ACTION_REQUIRED`; `READY` solo solicita integración y revisión independiente.
- A archiva evidencia en runs y cambia estado global; E revisa la revisión integrada antes de cualquier `DONE`.
- Si falta una dependencia, delimita el bloqueo y el siguiente paso; no simules conectividad ni certificación de gates.
