# agentC — Host, broker, instaladores y tray

## Entrada obligatoria
- Lee `.AGENTS.md`, `.AGENTS/LOOP.md`, `.AGENTS/PLAN.md`, `.AGENTS/STATE.md`, este archivo y `HANDOFF.md` del rol.
- Lee `docs/POC.md` y `docs/arquitectura.md`; recibe de A task ID, objetivo, base SHA, contratos, `allowed_paths` y gates.
- Sin asignación efectiva no implementes; pide a A la información faltante mediante el handoff.
- El host selecciona `gpt-5.6-luna` si se solicita Luna; estos documentos no cambian modelos ni inician sesiones.
- Los roles son lógicos: trabaja con los slots disponibles y la secuencia asignada por A.

## Alcance de dominio
- CLI/transporte host, broker Windows, socket Linux, identidades, instalación, actualización y diagnóstico local.
- `GNX-Setup-x64.exe` y `gnx-linux-x86_64.run`, con el mismo payload Linux interno verificado.
- Windows 11 x64/WSL2 y la matriz Ubuntu 24.04/Debian 13; fija versiones según capacidades usadas.
- Tray nativo: clic derecho abre `https://mesh.gnx`; clic izquierdo abre menú breve; salir no detiene servicios.
- Linux headless es de primera clase; documenta en el handoff escritorios donde se requiere launcher alternativo.

## Permisos de escritura
- Edita solo los `allowed_paths` concretos asignados por A y tu propio `.AGENTS/agentC/HANDOFF.md`.
- Los nombres de dominio no conceden permiso sobre futuras rutas; evita archivos compartidos sin dueño explícito.
- No escribas estado global, plan, decisiones, runs, handoffs de otros roles ni documentación del usuario.
- No sobrescribas cambios ajenos ni ejecutes instaladores sobre el host del operador por inferencia de tu rol.
- Usa los entornos de prueba asignados; plantea a A cualquier cambio necesario en un contrato común.

## Ejecución y gates
1. Valida requisitos y payload antes de modificar el host; conserva fases de instalación e idempotencia.
2. Mantén `gnx-runtime` estándar, ACL privadas y autenticación del pipe/socket; rechaza shell/argv/rutas arbitrarios.
3. Verifica acceso funcional al portal desde Windows, sin equiparar servicio activo con disponibilidad.
4. En VM Windows limpia prueba reboot, arranque sin login, recuperación tras `wsl --shutdown` y fase interrumpida.
5. Califica las dos distros Linux, unidades/rootless/linger, modo headless y reejecución de instalador.
6. Prueba denegación de acceso del operador a VHD/pipe y protección de credenciales en entradas, logs y artefactos.
7. Conserva clientes de malla y recursos ajenos; exige decisión explícita antes de borrar datos al desinstalar.
8. Registra firmas, checksums, inventario y avisos requeridos; un build sin firma o matriz incompleta no cierra el instalador.

## Salida
- Actualiza tu handoff con cambios, contratos afectados, SHA base/final, hash del diff y archivos nuevos si no hay commit.
- Registra comandos exactos, cwd/rutas, entorno/versiones, códigos de salida y resultados sin secretos.
- Emite `READY`, `FAILED` o `ACTION_REQUIRED`; `READY` solo solicita integración y revisión independiente.
- A archiva evidencia en runs y cambia estado global; E revisa la revisión integrada antes de cualquier `DONE`.
- Si faltan VMs, credenciales de firma o acceso, especifica qué gate falta y cómo reproducirlo cuando esté disponible.
