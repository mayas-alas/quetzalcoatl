# Decisiones persistentes

| ID | Decisión | Razón / alcance |
|---|---|---|
| D001 | `.AGENTS.md` es canónico y `AGENTS.md` es su cargador | Estructura solicitada y descubrimiento estándar de Codex |
| D002 | Gauntlet conducido por el agente, con entrada en cada season | El usuario solicita un prompt reinyectable; no se instala un daemon ni se programan sesiones |
| D003 | Futuros workers usan gpt-5.6-luna, seleccionado en el host | Preferencia del usuario; el archivo Markdown no cambia el modelo |
| D004 | El backlog conserva el cierre íntegro de las dos especificaciones | No confundir sistema preparado con GNX implementado |
| D005 | S000 valida solamente el sistema de coordinación | Toda tarea de producto empieza TODO; no se ejecutan instaladores ni cambios del host durante el bootstrap |

P00 debe registrar lenguaje, herramientas, rutas de código, versiones fijadas,
comandos de build/prueba y entornos disponibles. Sigue las decisiones arquitectónicas
de `docs/`; no inventes aprobaciones de cambios de alcance. Anota decisiones nuevas
con ID, fecha, motivo, consecuencias, alternativa descartada cuando importe y
requisitos afectados. Cambiar una decisión no convierte sus pruebas pendientes en PASS.
