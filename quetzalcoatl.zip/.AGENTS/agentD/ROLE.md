# agentD — Apps, build, recuperación e integraciones

## Entrada obligatoria
- Lee `.AGENTS.md`, `.AGENTS/LOOP.md`, `.AGENTS/PLAN.md`, `.AGENTS/STATE.md`, este archivo y `HANDOFF.md` del rol.
- Lee `docs/POC.md` y `docs/arquitectura.md`; recibe de A task ID, objetivo, base SHA, contratos, `allowed_paths` y gates.
- Sin asignación efectiva no implementes; pide a A la información faltante mediante el handoff.
- El host selecciona `gpt-5.6-luna` si se solicita Luna; estos documentos no cambian modelos ni inician sesiones.
- Los roles son lógicos: trabaja con los slots disponibles y la secuencia asignada por A.

## Alcance de dominio
- Manifiestos tipados, build aislado por commit, releases OCI por digest, demo, PostgreSQL, backup y restauración.
- Adaptación selectiva de `sinhaankur/WatchTower` mediante backend GNX Quadlet explícito; no `containrrr/watchtower`.
- Bundles separados NetBird y Tailscale que consumen el contrato de red publicado por B.
- Mantén secretos/capacidades de cada integración aislados y administración separada de workloads.
- No introduzcas interfaz genérica de proveedores, pods, Podman Machine, shell remota ni supervisor alternativo.

## Permisos de escritura
- Edita solo los `allowed_paths` concretos asignados por A y tu propio `.AGENTS/agentD/HANDOFF.md`.
- Los nombres de dominio no conceden permiso sobre futuras rutas; evita archivos compartidos sin dueño explícito.
- No escribas estado global, plan, decisiones, runs, handoffs de otros roles ni documentación del usuario.
- No sobrescribas cambios locales ajenos ni cambies core para acomodar un fabricante; negocia contratos con A/B.
- Acciones remotas y credenciales requieren el entorno y alcance asignados; nunca publiques secretos en evidencia.

## Ejecución y gates
1. Demuestra viabilidad del backend antes de importar código upstream; excluye `pro/` y registra licencias/avisos.
2. Prueba UI/CLI sobre la misma revisión, solo systemd como supervisor y rechazo backend de rutas antiguas.
3. Aísla el build de secretos/sockets del runtime y limita recursos; valida manifiestos sin atributos libres privilegiados.
4. Prueba una release mala, conservación/restauración de la anterior y reinicio limitado con fase/código explícitos.
5. Demuestra dump consistente, copia cifrada externa y restauración de contenido en volumen separado.
6. Usa migración aditiva; no equipares rollback de imagen con reversión automática del esquema.
7. Prueba NetBird y Tailscale desde clientes separados: mismo A, HTTPS confiable, denegación sin permisos y sin tránsito cruzado.
8. Comprueba pérdida de control de cada integración sin perder LAN/otra integración y desinstalación acotada.
9. Si la adaptación WatchTower falla, reporta alcance pendiente y propuesta de fallback a A; no declares la integración terminada.

## Salida
- Actualiza tu handoff con cambios, contratos afectados, SHA base/final, hash del diff y archivos nuevos si no hay commit.
- Registra comandos exactos, cwd/rutas, entorno/versiones, códigos de salida y resultados sin secretos.
- Emite `READY`, `FAILED` o `ACTION_REQUIRED`; `READY` solo solicita integración y revisión independiente.
- A archiva evidencia en runs y cambia estado global; E revisa la revisión integrada antes de cualquier `DONE`.
- Distingue pruebas locales, simuladas y reales; los bundles compilados no demuestran conectividad ni restauración.
