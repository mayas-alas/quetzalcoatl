"""Regresiones del control documental, sin lanzar agentes ni modificar el repo."""

from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
from pathlib import Path
import sys
import tempfile
import unittest


MODULE_PATH = Path(__file__).resolve().parents[1] / "scripts" / "gauntlet.py"
SPEC = importlib.util.spec_from_file_location("gauntlet", MODULE_PATH)
gauntlet = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = gauntlet
SPEC.loader.exec_module(gauntlet)


class GauntletTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        paths = list(gauntlet.SYSTEM_FILES) + list(gauntlet.PRODUCT_FILES)
        paths.extend(f".AGENTS/{role}/{name}.md" for role in gauntlet.ROLES for name in ("ROLE", "HANDOFF"))
        for path in paths:
            self.write(path, "Contenido inicial.\n")
        self.plan("| P00 | Base | agentB | - |\n| P01 | Integrar | agentC | P00 |")
        self.state("| P00 | TODO | - | - |\n| P01 | TODO | - | - |")

    def write(self, relative, text):
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")

    def plan(self, rows):
        self.write(".AGENTS/PLAN.md", "| ID | Trabajo | Rol | Depende de |\n|---|---|---|---|\n" + rows + "\n")

    def state(self, rows, poc="NOT_STARTED", season="S000"):
        self.write(".AGENTS/STATE.md", f"PoC: {poc}\nSeason: {season}\n\n| ID | Estado | Responsable | Evidencia |\n|---|---|---|---|\n{rows}\n")

    def run_cli(self, *args):
        stdout, stderr = io.StringIO(), io.StringIO()
        with redirect_stdout(stdout), redirect_stderr(stderr):
            result = gauntlet.main(list(args), root=self.root)
        return result, stdout.getvalue(), stderr.getvalue()

    def test_prompt_reloads_state_and_does_not_write(self):
        before = {path.relative_to(self.root): path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        result, original, error = self.run_cli("prompt", "--season", "S001")
        self.assertEqual((result, error), (0, ""))
        after = {path.relative_to(self.root): path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        self.assertEqual(before, after)
        self.state("| P00 | IN_PROGRESS | agentB | - |\n| P01 | TODO | - | - |", poc="ACTIVE", season="S001")
        result, fresh, error = self.run_cli("prompt", "--season", "S002", "--role", "agentB")
        self.assertEqual((result, error), (0, ""))
        self.assertNotIn("| P00 | IN_PROGRESS", original)
        self.assertIn("| P00 | IN_PROGRESS", fresh)
        self.assertTrue(fresh.endswith("Season: S002\nRole: agentB\n"))
        self.assertIn(".AGENTS/agentB/HANDOFF.md", fresh)

    def test_rejects_cycle_unknown_dependency_and_duplicate_id(self):
        for rows, message in (
            ("| P00 | Base | agentB | P01 |\n| P01 | Integrar | agentC | P00 |", "ciclo de dependencias"),
            ("| P00 | Base | agentB | P99 |\n| P01 | Integrar | agentC | P00 |", "dependencia desconocida P99"),
            ("| P00 | Base | agentB | - |\n| P00 | Duplicada | agentC | - |", "ID duplicado P00"),
        ):
            with self.subTest(message=message):
                self.plan(rows)
                self.assertTrue(any(message in error for error in gauntlet.check(self.root)))

    def test_rejects_premature_work_and_false_complete(self):
        self.state("| P00 | TODO | - | - |\n| P01 | IN_PROGRESS | agentC | - |", poc="COMPLETE")
        errors = "\n".join(gauntlet.check(self.root))
        self.assertIn("IN_PROGRESS requiere dependencias DONE: P00", errors)
        self.assertIn("COMPLETE exige", errors)
        result, output, error = self.run_cli("prompt", "--season", "S001")
        self.assertEqual((result, output), (1, ""))
        self.assertIn("COMPLETE exige", error)

    def test_done_needs_local_evidence_and_valid_dependencies(self):
        self.state("| P00 | DONE | agentB | [registro](evidence/missing.md) |\n| P01 | DONE | agentC | https://example.com/proof |", poc="COMPLETE")
        errors = "\n".join(gauntlet.check(self.root))
        self.assertIn("enlace local inexistente", errors)
        self.assertIn("STATE P00: DONE exige", errors)
        self.assertIn("STATE P01: DONE exige", errors)
        self.write(".AGENTS/evidence/run.md", "Resultado registrado; la herramienta solo comprueba que existe.\n")
        self.state("| P00 | DONE | agentB | [registro](evidence/run.md) |\n| P01 | DONE | agentC | [registro](evidence/run.md) |", poc="COMPLETE")
        self.assertEqual(gauntlet.check(self.root), [])

    def test_checks_links_but_ignores_fences_urls_and_anchors(self):
        self.write(".AGENTS/START.md", "[externo](https://example.com/x) [ancla](#inicio)\n```md\n[falso](missing.md)\n```\n~~~md\n[falso](missing2.md)\n~~~\n[real](PLAN.md)\n")
        self.assertEqual(gauntlet.check(self.root), [])
        self.write(".AGENTS/START.md", "[registro][ref]\n\n[ref]: evidence/missing.md\n")
        self.assertTrue(any("enlace local inexistente" in error for error in gauntlet.check(self.root)))

    def test_ignores_other_tables_after_the_plan(self):
        path = self.root / ".AGENTS/PLAN.md"
        path.write_text(path.read_text(encoding="utf-8") + "\n## Matriz de aceptación\n\n| Fuente | Requisito |\n|---|---|\n| Producto | Validación real |\n", encoding="utf-8")
        self.assertEqual(gauntlet.check(self.root), [])

    def test_rejects_state_drift_missing_role_and_unknown_status(self):
        self.state("| P00 | FAKED | robot | - |\n| P00 | TODO | - | - |\n| P99 | TODO | - | - |")
        (self.root / ".AGENTS/agentE/HANDOFF.md").unlink()
        errors = "\n".join(gauntlet.check(self.root))
        for message in ("agentE/HANDOFF.md", "estado desconocido", "responsable inválido", "ID duplicado P00", "falta el ID P01", "ID P99 no existe"):
            self.assertIn(message, errors)


if __name__ == "__main__":
    unittest.main()
