# Prompt de entrada · repetir en cada sesión

Copia el bloque siguiente en una sesión de Luna abierta en este repositorio.
La primera campaña usa S001; después usa una season nueva y conserva el progreso.
Una season es una sesión de trabajo, no un reinicio del proyecto.

```text
Actúa como agentA para GNX. Lee AGENTS.md, .AGENTS.md y .AGENTS/LOOP.md;
después .AGENTS/STATE.md, PLAN.md, DECISIONS.md, tu ROLE.md/HANDOFF.md
y docs/arquitectura.md + docs/POC.md. Recupera el último checkpoint.

Objetivo de campaña: implementar y demostrar TODO el PoC de esos documentos,
incluidos ambos instaladores, las dos integraciones independientes, GNX Apps,
WatchTower, recuperación y datos. Sigue el gauntlet loop ya definido.

Usa gpt-5.6-luna para los workers cuando el host permita seleccionarlo.
Registra el modelo real, asigna tareas acotadas con rutas exclusivas y entrega
a cada worker su contexto, dependencias, criterios y evidencia esperada.
Lee los archivos directamente; no supongas que los workers heredan el chat.

Reanuda tareas interrumpidas verificando disco y procesos antes de reasignarlas.
Ejecuta, verifica, solicita revisión independiente, corrige y continúa con la
siguiente tarea disponible hasta el cierre completo. No termines solo con un
plan, scaffolding, tests simulados o una lista de recomendaciones.

No declares DONE sin evidencia del entorno requerido y aceptación independiente.
Si aparece un bloqueo externo, registra causa y acción mínima para desbloquear;
continúa tareas independientes. Antes de salir guarda STATE, HANDOFF y el reporte
de season con la siguiente acción exacta. Responde brevemente en español.
```

## Uso

Entrada corta equivalente: **Lee `.AGENTS/START.md` y ejecuta la siguiente season
del gauntlet hasta completar el PoC o documentar un bloqueo externo real.**

Para preparar la entrada con el estado actual, desde la raíz:

```powershell
python scripts/gauntlet.py check
python scripts/gauntlet.py prompt --season S001
```

El segundo comando imprime contexto fresco para pegar en el agente. No llama a
modelos, programa sesiones ni modifica STATE. El agente ejecuta el loop al recibir
la entrada. Para workers, agentA puede usar `--role agentB` y adjuntar el
[paquete de tarea](templates/TASK.md); cada worker necesita una asignación concreta.
No se inician tareas nuevas en la app ni ejecuciones futuras automáticamente.

`AGENTS.md` carga el contrato con punto sin cambiar configuración global.
[Referencia de descubrimiento de Codex](https://learn.chatgpt.com/docs/agent-configuration/agents-md).
