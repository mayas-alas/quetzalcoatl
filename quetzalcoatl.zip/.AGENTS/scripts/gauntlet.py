#!/usr/bin/env python3
"""Valida el sistema documental e imprime un prompt; nunca modifica archivos.

Python 3, biblioteca estándar. El repositorio se encuentra a partir de este
archivo, por lo que ambos comandos funcionan desde cualquier directorio.
S000 se admite para una prueba de arranque sin comenzar una season de trabajo.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlsplit


ROOT = Path(__file__).resolve().parent.parent
ROLES = tuple(f"agent{letter}" for letter in "ABCDE")
SYSTEM_FILES = (
    "AGENTS.md",
    ".AGENTS.md",
    ".AGENTS/START.md",
    ".AGENTS/LOOP.md",
    ".AGENTS/PLAN.md",
    ".AGENTS/STATE.md",
    ".AGENTS/DECISIONS.md",
)
PRODUCT_FILES = ("docs/arquitectura.md", "docs/POC.md")
STATES = {"TODO", "IN_PROGRESS", "REVIEW", "DONE", "BLOCKED"}
POC_STATES = {"NOT_STARTED", "ACTIVE", "BLOCKED", "COMPLETE"}
SEASON_RE = re.compile(r"S\d{3,}\Z")
ID_RE = re.compile(r"P\d{2,}\Z")


@dataclass(frozen=True)
class PlanItem:
    role: str
    dependencies: tuple[str, ...]


@dataclass(frozen=True)
class StateItem:
    status: str
    owner: str
    evidence: str


def unfenced(source: str) -> str:
    """Retira fences Markdown (backticks o tildes) antes de analizar texto."""
    lines: list[str] = []
    fence_char = ""
    fence_size = 0
    for line in source.splitlines():
        match = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", line)
        if fence_char:
            if (
                match
                and match[1][0] == fence_char
                and len(match[1]) >= fence_size
                and not match[2].strip()
            ):
                fence_char = ""
            lines.append("")
        elif match:
            fence_char, fence_size = match[1][0], len(match[1])
            lines.append("")
        else:
            lines.append(line)
    return "\n".join(lines)


def markdown_links(source: str) -> list[str]:
    """Extrae destinos inline y de referencias, fuera de fences.

    Admite destinos entre <...>, títulos opcionales y paréntesis en rutas.
    Las referencias se comprueban por su definición, aunque no se usen.
    """
    source = unfenced(source)
    destinations: list[str] = []
    # Definiciones de referencia: [evidencia]: ../evidence/run.md
    for match in re.finditer(r"^ {0,3}\[[^\]\n]+\]:\s*(<[^>\n]+>|\S+)", source, re.M):
        destinations.append(match[1].strip("<>"))
    # Un pequeño escáner evita cortar nombres como resultado(test).md.
    for match in re.finditer(r"(?<!!)\[[^\]\n]*\]\(\s*|!\[[^\]\n]*\]\(\s*", source):
        start = match.end()
        if start < len(source) and source[start] == "<":
            end = source.find(">", start + 1)
            if end != -1:
                destinations.append(source[start + 1 : end])
            continue
        depth = 0
        index = start
        while index < len(source):
            char = source[index]
            if char == "\\" and index + 1 < len(source):
                index += 2
                continue
            if char == "(":
                depth += 1
            elif char == ")":
                if depth == 0:
                    break
                depth -= 1
            elif char.isspace() and depth == 0:
                break
            index += 1
        if index > start:
            destinations.append(source[start:index])
    return destinations


def local_target(document: Path, destination: str) -> Path | None:
    destination = destination.strip()
    if not destination or destination.startswith(("#", "//")):
        return None
    # Esquemas (https:, mailto:, etc.) son externos; no se consulta la red.
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", destination):
        return None
    try:
        raw_path = urlsplit(destination).path
    except ValueError:
        return document.parent / destination
    if not raw_path:
        return None
    raw_path = re.sub(r"\\([()\[\] ])", r"\1", unquote(raw_path))
    return document.parent / raw_path


def table_rows(source: str, headers: tuple[str, ...], label: str, errors: list[str]) -> list[list[str]]:
    rows: list[list[str]] = []
    found = False
    active = False
    for line in unfenced(source).splitlines():
        stripped = line.strip()
        if not stripped.startswith("|"):
            active = False
            continue
        cells = [cell.strip() for cell in stripped.strip("|").split("|")]
        normalized = tuple(cell.casefold() for cell in cells)
        expected = tuple(header.casefold() for header in headers)
        if normalized == expected or (
            label == "PLAN" and normalized == ("id", "trabajo", "rol", "depende de ids")
        ):
            if found:
                errors.append(f"{label}: cabecera de tabla duplicada.")
            found = True
            active = True
            continue
        if not active or all(re.fullmatch(r":?-{3,}:?", cell) for cell in cells):
            continue
        if len(cells) != len(headers):
            errors.append(f"{label}: fila inválida (se esperaban {len(headers)} columnas): {stripped}")
            continue
        rows.append(cells)
    if not found:
        errors.append(f"{label}: falta la tabla {' | '.join(headers)}.")
    elif not rows:
        errors.append(f"{label}: la tabla no contiene tareas.")
    return rows


def parse_plan(source: str, errors: list[str]) -> dict[str, PlanItem]:
    items: dict[str, PlanItem] = {}
    for task_id, work, role, dependency_cell in table_rows(
        source, ("ID", "Trabajo", "Rol", "Depende de"), "PLAN", errors
    ):
        if not ID_RE.fullmatch(task_id):
            errors.append(f"PLAN: ID inválido {task_id!r}; usa P00, P01, etc.")
        if task_id in items:
            errors.append(f"PLAN: ID duplicado {task_id}.")
            continue
        if not work:
            errors.append(f"PLAN {task_id}: Trabajo está vacío.")
        if role not in ROLES:
            errors.append(f"PLAN {task_id}: rol desconocido {role!r}.")
        dependencies = () if dependency_cell == "-" else tuple(part.strip() for part in dependency_cell.split(","))
        if any(not ID_RE.fullmatch(dependency) for dependency in dependencies):
            errors.append(f"PLAN {task_id}: dependencias inválidas {dependency_cell!r}.")
        if len(set(dependencies)) != len(dependencies):
            errors.append(f"PLAN {task_id}: dependencia duplicada.")
        items[task_id] = PlanItem(role, dependencies)
    return items


def parse_state(source: str, errors: list[str]) -> tuple[dict[str, StateItem], str, str]:
    items: dict[str, StateItem] = {}
    text = unfenced(source)
    metadata: dict[str, str] = {}
    for name in ("PoC", "Season"):
        values = re.findall(rf"^{name}:\s*(\S+)\s*$", text, re.M)
        if len(values) != 1:
            errors.append(f"STATE: se necesita exactamente una línea '{name}: VALOR'.")
        metadata[name] = values[0] if values else ""
    if metadata["PoC"] not in POC_STATES:
        errors.append(f"STATE: PoC inválido {metadata['PoC']!r}; usa {', '.join(sorted(POC_STATES))}.")
    if not SEASON_RE.fullmatch(metadata["Season"]):
        errors.append("STATE: Season debe tener formato S000, S001, etc.")
    for task_id, status, owner, evidence in table_rows(
        source, ("ID", "Estado", "Responsable", "Evidencia"), "STATE", errors
    ):
        if not ID_RE.fullmatch(task_id):
            errors.append(f"STATE: ID inválido {task_id!r}.")
        if task_id in items:
            errors.append(f"STATE: ID duplicado {task_id}.")
            continue
        if status not in STATES:
            errors.append(f"STATE {task_id}: estado desconocido {status!r}.")
        if owner not in ROLES and not (status == "TODO" and owner == "-"):
            errors.append(f"STATE {task_id}: responsable inválido {owner!r} para {status}.")
        items[task_id] = StateItem(status, owner, evidence)
    return items, metadata["PoC"], metadata["Season"]


def check(root: Path = ROOT) -> list[str]:
    """Retorna errores estructurales leyendo el disco en esta invocación."""
    root = Path(root)
    errors: list[str] = []
    required = list(SYSTEM_FILES) + list(PRODUCT_FILES)
    required.extend(f".AGENTS/{role}/{filename}.md" for role in ROLES for filename in ("ROLE", "HANDOFF"))
    sources: dict[str, str] = {}
    for relative in required:
        path = root / relative
        try:
            source = path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError) as exc:
            errors.append(f"{relative}: no se puede leer ({exc}).")
            continue
        if not source.strip():
            errors.append(f"{relative}: archivo vacío.")
        sources[relative] = source

    system_paths = {root / "AGENTS.md", root / ".AGENTS.md"}
    system_paths.update((root / ".AGENTS").rglob("*.md"))
    for document in sorted(system_paths):
        relative = document.relative_to(root).as_posix()
        try:
            source = sources.get(relative)
            if source is None:
                source = document.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError) as exc:
            if relative not in required:
                errors.append(f"{relative}: no se puede leer ({exc}).")
            continue
        for destination in markdown_links(source):
            target = local_target(document, destination)
            if target is not None and not target.exists():
                errors.append(f"{relative}: enlace local inexistente {destination!r}.")

    plan = parse_plan(sources.get(".AGENTS/PLAN.md", ""), errors)
    state, poc, _season = parse_state(sources.get(".AGENTS/STATE.md", ""), errors)
    for task_id in sorted(plan.keys() - state.keys()):
        errors.append(f"STATE: falta el ID {task_id} de PLAN.")
    for task_id in sorted(state.keys() - plan.keys()):
        errors.append(f"STATE: ID {task_id} no existe en PLAN.")

    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(task_id: str, path: tuple[str, ...]) -> None:
        if task_id in visiting:
            errors.append(f"PLAN: ciclo de dependencias {' -> '.join(path + (task_id,))}.")
            return
        if task_id in visited:
            return
        visiting.add(task_id)
        for dependency in plan[task_id].dependencies:
            if dependency not in plan:
                errors.append(f"PLAN {task_id}: dependencia desconocida {dependency}.")
            else:
                visit(dependency, path + (task_id,))
        visiting.remove(task_id)
        visited.add(task_id)

    for task_id in plan:
        visit(task_id, ())
    for task_id, item in state.items():
        if task_id not in plan:
            continue
        if item.status in {"IN_PROGRESS", "REVIEW", "DONE"}:
            pending = [
                dependency for dependency in plan[task_id].dependencies
                if dependency not in state or state[dependency].status != "DONE"
            ]
            if pending:
                errors.append(f"STATE {task_id}: {item.status} requiere dependencias DONE: {', '.join(pending)}.")
        if item.status == "DONE":
            targets = [local_target(root / ".AGENTS/STATE.md", link) for link in markdown_links(item.evidence)]
            if not any(target is not None and target.is_file() for target in targets):
                errors.append(f"STATE {task_id}: DONE exige un enlace Markdown a un archivo local de evidencia existente.")
    if poc == "COMPLETE" and (not plan or set(plan) != set(state) or any(item.status != "DONE" for item in state.values())):
        errors.append("STATE: PoC COMPLETE exige que todas las tareas del plan estén DONE.")
    if poc == "NOT_STARTED" and any(item.status != "TODO" for item in state.values()):
        errors.append("STATE: PoC NOT_STARTED exige que todas las tareas estén TODO.")
    if poc == "BLOCKED" and not any(item.status == "BLOCKED" for item in state.values()):
        errors.append("STATE: PoC BLOCKED exige al menos una tarea BLOCKED.")
    return errors


def build_prompt(root: Path, season: str, role: str) -> str:
    """Construye el prompt usando contenido actual, sin reusar snapshots."""
    explicit = list(SYSTEM_FILES) + [f".AGENTS/{role}/ROLE.md", f".AGENTS/{role}/HANDOFF.md"] + list(PRODUCT_FILES)
    lines = [
        "Trabaja en este repositorio GNX con el paradigma Gauntlet descrito en los documentos locales.",
        f"Tu rol de esta sesión es {role}; sigue su ROLE.md y el paquete asignado en su HANDOFF.md.",
        "Lee explícitamente, en este orden, estos archivos completos antes de actuar:",
        *[f"- {relative}" for relative in explicit],
        "",
        "Sigue el loop de .AGENTS/LOOP.md y respeta dependencias, propiedad de archivos y gates.",
        "Relee el estado del disco antes de elegir trabajo y antes de integrar resultados de otros agentes.",
        "El contenido adjunto es una entrada de sesión; los archivos actuales del repositorio son la fuente de verdad.",
        (
            "Como agentA, coordina la campaña y delega a agentes Luna según los roles y paquetes definidos."
            if role == "agentA"
            else "Como trabajador, implementa únicamente el paquete asignado y entrega su evidencia y handoff. "
            "START.md se adjunta como contexto de campaña: las instrucciones para coordinar, delegar o cerrar toda la campaña "
            "corresponden exclusivamente a agentA. Si falta un paquete asignado, registra ese bloqueo en tu handoff."
        ),
        "Conserva evidencia verificable y comunica bloqueos concretos. Nunca declares el PoC completo por pasar el check documental.",
        "S000 está reservado para una prueba de arranque (smoke); no cuenta como ejecución ni cierre del PoC.",
        "",
    ]
    for relative in (".AGENTS/START.md", ".AGENTS/STATE.md", f".AGENTS/{role}/ROLE.md", f".AGENTS/{role}/HANDOFF.md"):
        lines.extend((f"===== CONTENIDO ACTUAL: {relative} =====", (root / relative).read_text(encoding="utf-8-sig").rstrip(), ""))
    lines.extend(("===== ENTRADA DE ESTA SESIÓN =====", f"Season: {season}", f"Role: {role}"))
    return "\n".join(lines) + "\n"


class CliParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        self.print_usage(sys.stderr)
        self.exit(1, f"Error: {message}\n")


def main(argv: list[str] | None = None, *, root: Path = ROOT) -> int:
    parser = CliParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True, parser_class=CliParser)
    subparsers.add_parser("check", help="Valida archivos, enlaces, plan y estado; no verifica el producto.")
    prompt_parser = subparsers.add_parser("prompt", help="Valida e imprime la entrada de una season; no lanza agentes.")
    prompt_parser.add_argument("--season", required=True, help="S001, S002, etc.; S000 admite smoke.")
    prompt_parser.add_argument("--role", default="agentA", choices=ROLES)
    args = parser.parse_args(argv)
    if args.command == "prompt" and not SEASON_RE.fullmatch(args.season):
        parser.error("--season debe tener formato S001 (S seguido de al menos tres dígitos).")
    errors = check(root)
    if errors:
        print("El sistema documental tiene errores:", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    if args.command == "check":
        print("OK: estructura documental, enlaces, dependencias y estado coherentes. No valida la veracidad de evidencias ni el PoC.")
        return 0
    try:
        print(build_prompt(root, args.season, args.role), end="")
    except (OSError, UnicodeError) as exc:
        print(f"No se pudo releer el prompt actual: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
